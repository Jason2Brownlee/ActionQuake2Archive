
Name of skins          : Mason (from the movie "The Rock")
Model to be used with  : Male
Date                   : March 23, 1998
Author                 : Gliebster
E-mail                 : glieb@telefragged.com
Homepage               : f-shock.telefragged.com


FILES INCLUDED:
-----------
mason.pcx (Mason skin)
mason_i.pcx (Mason icon)
readme.txt (Your reading it)


ABOUT THE SKIN:
-----------
Well, one night I was watching a movie, a movie called "The Rock" and 
damn (!) does that movie kick ass!  So the next day I got up and spent 
a couple hours working on a Mason skin.  I used the grunt as my base 
skin I swapped colors and changed the brightness/contrast on his armor
and edited some of his body and added sleeves.  I think I got his head 
just perfect!  The beard and everything looks just like him.

INSTALLATION:
------------
Place mason.pcx and mason_i.pcx into your quake2\baseq2\players\male 
dir.  


NOTES:
-----
I used PSP 5 beta, Ulead Photo Impact SE NSTv0.76 and JawMD2 v1.29 to 
create Mason.  You can distribute this skin around the net, just keep 
the readme & pcx files intact and don't try & say you made it, cause I'll 
hunt you down & kick your ass like the bastard you are the way Mason 
did in The Rock!  If you want to edit this skin, please contact me first.


CREDITS:
-----
Id software for making the game, Jawed Karim for making JawMD2 and 
NPherno for making NST.


-Gliebster