
 ---------------------------------------------------------------
 Title    : Action Quake2
 Filename : actn91cl.zip
 Version  : 0.91
 Date     : 5-17-98

 Author   : Sam 'Cail' Thompson
 Email    : mhoram@world-net.net

 Author   : Nathan 'Pietro' Kovner
 Email    : kovner@world-net.net

 Author   : Patrick 'Bartender' Mills
 Email    : pncmills@txdirect.net

 Author   : Jon 'jon' Delee
 Email    : gille@world-net.net

 Webpage  : http://action.telefragged.com
 
 Introduction to Action Quake
 ----------------------------
 Welcome to the Action Quake2 Beta. This program will allow you to access
any Action Quake2 servers running the same client version (.89).
 
 Action Quake2 is a DM mod designed along the lines of a good action
movie.  No BFGs or rapid fire rocket launchers here,  and not a plasma weapon or laser 
gun in sight.  What we DO have is a mod where stealth and strategy pay off more 
than the the ability to shoot yourself in the feet with a BFG.
 
 Installation
 ------------
 Simply unzip actn91cl.zip to your Quake 2 directory.  Now run Quake2
with:
 
 quake2 +set game action
 
 Basics
 ------
 In Action Quake2 you start with only a pistol and 10 bullets in the
clip.  In most games your starting weapon is little more than a glorified pea-shooter, 
not in this mod.  That's a .44 Desert Eagle, more than enough to lay down a foe, 
plus stopping power to boot.  Locational damage also insures that those shots to 
the head will get you a kill.  But be careful with those shots, ammo is sparse
compared to what you might be used to and you can hold only so much.  When running your 
accuracy drops dramatically, so stand still when lining up for that head-shot.
 
 So now you've taken a jaunt through the level and are wondering where
the other weapons are. 'This pistol is nice, but I want a shotgun.' you may be thinking.  
Well, in Action Quake2, weapons are unique, this means that if you see
someone running through the level with an uzi, that's the only uzi on
the level.  So shoot the guy and take it, you've earned it.  You can only 
carry one unique item at a time.  Of course, special items function in the same way.
 
 In this release there are 6 weapons: the pistol, the uzi, the shotgun,
the sniper rifle, grenades, and the hand cannon.  All but the grenades and 
the pistol are considered 'unique'.  See action.doc or go to our 
website (action.telefragged.com) for more details.
 
 As this is a beta release, we are very interested in player comments
and suggestions.  If you like the mod, tell us why.  If you hate the mod, 
tell us why.  And if you have any ideas that you think would make a good 
addition, please tell us.  You can write to us at ateam@telefragged.com
 
 Planned Editions
 ----------------
 -Teamplay Variants
         *Capture The Briefcase full of money/bomb/plot device
         *SWAT
         *Assassinate the CEO/Mob-Boss
 
 -More Weapons, Maps, Skins, Items
 
 -VWep Support
 
 -Send Us Your Ideas!

 -Check the "In Progress" section of the action.telefragged.com pages.

 Known Issues
 ------------
 Problems when running in software mode, these include disapearing doors
 Some odd grenade errors.

 Resolved Issues
 ---------------
 We fixed an cheat that some people were using to gain extra grenades.
 Fixed some other grenade bugs.
 
 New In This Version
 -------------------
New in v.91
* The "drop weapon" command will drop your unique weapon, even if you are using it.
* The "sniper" command allows you to toggle whether or not you are looking through the lens of the rifle (so you can put at your hip and walk around)
* The sniper rifle reloads more quickly.
* The server setting "actionmaps 1" or the cmd line "+set actionmaps 1" will rotate between the three action quake maps we have so far.
* The machinegun "rides up" like in singleplayer quake2.
* The handcannon is now less powerful.

New in v.90
* Shooting while walking makes you less accurate than while standing still, but more accurate than running.
* Shooting while crouching makes you more accurate than while standing still.
* The lasersight now makes you as accurate as you would be if you were crouching no matter what you are doing.
* Jumping into someone kicks them (a jumpkick)- it does 20 damage, knocks the target back pretty darn far, and disarms the person (forces him to drop his unique weapon)

New in v.89
* You cannot fire accurately while running.

New in v.88
* You can no longer drop grenades if you are using them.
* If someone shoots his enemy off a ledge, out a window etc. causing them to die from fall damage, the attacker recieves a frag and the target does not lose one.
* One or two new death messages.

New in v.87
* Servers no longer crash because of windows (we removed windows - if id tells you that you shouldn't have something in deathmatch, they mean it!)
* Gibbing should no longer occur, even with telefragging and the handcannon.

New in v.85

* Short falls do not cause fall damage (although long falls still cause the same amount of damage)
* The handcannon now shoots 35 pellets each 3 times as powerful as each of the 100(!) pellets it used to shoot.  The result: the handcannon still works the same, except it might be more random at long distances (which is good) We did this to fix the multiple overflow errors the handcannon had caused.
* Items (kevlar vest, silencer, lasersight) now spawn even if you decide to play more than one game!
* Lava now deals damage normally.
* The clips and magazines are now fullbright, and much easier to see.
* Bandaging is now independent of reloading (ie you shouldnt be healed when you reload the shotgun)


 Other Credits
 -------------
 Well, too many people to thank them all, really, but I would like to
thank Jeff for letting us use his LAN hub even though he doesn't play the mod.  
And of course to Telefragged for hosting us.  Props also to Skeeter from the #qoole channel
for helping us to resolve our name problem.  Also props to Action (no relation) also of the
#qoole channel for always answering our questions about level building.  Props to the guys at Rust 
(www.planetquake/rust).  Pietro gives em out to Geza Beladi (lasersight code) and Decker 
(HUD info) of QDevels (www.planetquake.com/qdevels).  Also going out to everyone who has hosted a 
server for us, thanks guys, we couldn't have gotten this far without you.
 
 Copyright and Distribution Permissions
 --------------------------------------
 
 This patch is freely distributable provided that this readme is
distributed as well and is unchanged.
 
 All the new art, models, code, maps, and sounds are copyright The
A-Team 1998.  Basically, if we made it, it's ours.
 
 DISCLAIMER:  We have tested this modification and found it to be
totally safe.  However, we cannot be held responsible for
anything that does happen to your computer resulting from the use of
this mod.  If something does happen, please write us
so that we can try to correct the problem.
 
 Contact
 -------
 You can find this mod and it's webpage at
 
 - http://action.telegragged.com
 
 We can be emailed at
 
 - ateam@telefragged.com
