
 ---------------------------------------------------------------
 Title    : Action Quake2
 Filename : actn95cl.zip
 Version  : 0.95
 Date     : 8-15-98

 Author   : Sam 'Cail' Thompson
 Email    : mhoram@world-net.net

 Author   : Patrick 'Bartender' Mills
 Email    : pncmills@txdirect.net
 
 Author   : Nathan 'Pietro' Kovner
 Email    : He's in Germany and doesn't want you peeps ruining his fun.
 
 Author   : Jon 'Vain' Delee
 Email    : gille@world-net.net

 Author	  : Evan 'Ace12GA' Prentice
 Email	  : ace12ga@telefragged.com

 Author	  : Minh "Gooseman" Le
 Email    : gooseman@telefragged.com

 Author   : Dallas 'Suislide' Frank
 Email    : elysium@fuse.net

 Webpage  : http://action.telefragged.com
 
 Introduction to Action Quake
 ----------------------------
 Welcome to the Action Quake2 Beta. This program will allow you to access
 any Action Quake2 servers running the same client version (.95).
 
 Action Quake2 is a DM mod designed along the lines of a good action
 movie.  No BFGs or rapid fire rocket launchers here,  and not a plasma weapon or laser 
 gun in sight.  What we DO have is a mod where stealth and strategy pay off more 
 than the ability to shoot yourself in the feet with a BFG.
 
 Installation
 ------------
 Simply run actn95cl.exe in your Quake 2 \ action directory.

 For example, if your quake2 directory is C:\quake2, then it will install to
 C:\quake2\action

 Now run Quake2 with:
 
 quake2 +set game action

 This is a Deathmatch ONLY mod, so you must join a server to play. If you simply want
 to look at a map, simply type 'map locknload' (for example) at the console.

 If you don't know what I'm talking about, this isn't the mod for you.
 
 Basics
 ------
 In Action Quake2 you start with only a pistol and 10 bullets in the
 clip.  In most games your starting weapon is little more than a glorified pea-shooter, 
 not in this mod.  That's a Mk23, more than enough to lay down a foe, 
 plus stopping power to boot.  Locational damage also insures that those shots to 
 the head will get you a kill.  But be careful with those shots, ammo is sparse
 compared to what you might be used to and you can hold only so much.  When running your 
 accuracy drops dramatically, so stand still when lining up for that head-shot.
 
 So now you've taken a jaunt through the level and are wondering where
 the other weapons are. 'This pistol is nice, but I want a shotgun.' you may be thinking.  
 Well, in Action Quake2, weapons are unique, this means that if you see
 someone running through the level with an MP5, that's the only MP5 on
 the level.  So shoot the guy and take it, you've earned it.  You can only 
 carry one unique item at a time.  Of course, special items function in the same way.
 
 In this release there are 6 weapons: the pistol, akimbo pistols, the MP5, the shotgun,
 the sniper rifle, grenades, the assault rifle, and the hand cannon.  All but the grenades and 
 the pistol are considered 'unique'.  See action.doc or go to our 
 website (action.telefragged.com) for more details.
 
 As this is a beta release, we are very interested in player comments
 and suggestions.  If you like the mod, tell us why.  If you hate the mod, 
 tell us why.  And if you have any ideas that you think would make a good 
 addition, please tell us.  You can write to us at ateam@telefragged.com
 
 Planned Additions
 ----------------
 -Teamplay Variants
         *Assassinate the Leader
 
 -More Weapons, Maps, Skins, Items
 
 -VWep Support
 
 -Send Us Your Ideas!

 -Check the "In Progress" section of the action.telefragged.com pages.

 
 New In This Version
 -------------------
 New in v.95

* Sniper rifle changes:
	* No more 'sniper command' instead, there is 1x, 2x, 4x, 6x, where 1x is normal view
	  this means that the sniper rifle is really innaccurate when you 'hipshot it' (1x)
	* The sniper rifle ammo system: it now hold 10 rounds in the chamber, and you can have 20 rounds outside of that
	* fire time is much lower, but you now have to reload in between shots (just like the shotgun)
	* It's absoultely perfectly accurate if zoomed in.
	* Opponents death/pain noises are much quieter, for stealth reasons
	* Instead of 'lens' it is now 'weapon'. Weapon is a general command for each weapon, but only works onthe sniper and pistol

* Handcannon changes:
	* Tweaked for power a tad.
	* New model by suislide
	* You have to manually reload between shots. It's better this way, trust us.

* Combat Knife:
	* Model by suislide
	* Hits 5 times over the period of 1/2 second
	* 5 hits = damage of pistol (total damage I mean)
	* Locational damage, and can go right thru a vest
	* Opponents death/pain noises are much quieter, for stealth reasons
	* Everyone gets one

* Akimbo Pistols:
	* Model by gooseman
	* Comes with 12 rounds plus however much was left in your single pistol
	* Needs 2 clips to reload, and reloads to 24 rounds (12 in each)
	* "Movie Magic" will often even the # of rounds between the two guns
	* Damage = pistol
	* Spread = less than mp5 (or so)
	* Person drops it when they die (instead of pistol clip)
	* Counts as a pistol clip if you already have akimbo
	* Rocks.

* Grenades:
	* Model by abraxis, skin by suislide
	* Damage to self is no longer halved (just as likely to die by own grenade as opponents now)
	* Damage to anyone can be halved by ducking when it explodes (drop to the floor foo!!!)
	* Animations actually show pin-ness
	* Can't bandage while holding pin (doh!)
	* No stupid ass bugs

* Colt M4 Assault Rifle:
	* Model by gooseman
	* Bullets shoot thru people and do pistol round damage (about)
	* Makes sparks when it hits a wall
	* Fire rate = fast as mp5
	* Spread slightly greater than pistol
	* Best weapon in game bar none
	* Comes with 20 rounds per clip
	* Max of 1 extra clip (we HAVE to balance it somewhere =P )
	
* MP5/10 Submachinegun:
	* Accuracy increased substantially to make up for M4

* Pistol:
	* Range modifiers. At 600 texels the damage becomes 2/3. At 1400 texels, the damage becomes 1/2.
	* You won't notice unless you snipe with it. Range modifiers also apply to akimbo
	* Hit 'weapon' to switch between semi-auto and auto fire. Semi auto is 75% the spread (more accurate)

* Jump kick 
	* New "Bruce Lee-like" sound..

* Graphics changes:
	* Bullet holes caused by all gun weapons except shotgun/handcannon (lag reasons)
	* When you get shot, blood shoots out the back of you. Wherever this 'blood' hits, it leaves a blood stain (as in, brains on the wall)
	* When you are bleeding, every other second you bleed from the last point you were hit. Where the blood hits = blood stain (blood trail!)
	* Guns now lie on the ground and stay still (in contrast to floating rotating weapons)
	* When you drop an item/gun (from death, or other) it spins thru the air (looks cool) =P
	* New icons/.pcxs/etc. by snigglet

* Server changes:
	* External choice map rotation is in. Say what? If you put an action.ini file in your action directory, it will rotate the maps you choose.
		* The format of this is: (begin sample action.ini)
[Maplist]
office3
hostage
prison76
###
	(end sample action.ini)
		* a sample will be included with the client
		* You MUST SET actionmaps TO 1.. ie:
actionmaps 1 (at console) or
+set actionmaps 1 (at prompt)

		* If it doesn't work, it will tell you what went wrong
		* BIG THANKS to Geist(geist@mindspring.com) for his tutorial at Qdevels (www.planetquake.com/qdevels) I used it as the basis for my ideas, and snippets of his code
		* Will display map list to user when they join a server or go to new map

	* Various new options including:
		* bholelimit #	 (where # = the # of bullet holes max.. they will disappear after 1 minute no matter what tho - defaults to 0)
		* splatlimit #   (same as bholelimit, but for blood splats. defaults to 0 as well)
		* shelloff # (where # = 0 or 1. 0 means shells are on, 1 means shells are off. Defaults to 1)

* Gameplay changes:
	* New Item: Silent Slippers. Take away all feet noises. You're as quiet as you wanna be, and can still run.
	* New Item: Bandolier. Doubles or increases ammo count on all weapons. Not for in gun, but extra clips... etc.
	* Can now pickup an item you drop
	* Lasersight/silencer no longer drop your gun (gameplay over realism)
	* Jumping no longer makes that stupid-ass grunt (IMO), but there's still a landing noise
	

AND MUCH MUCH MORE! 


New in v.93
* The new models from Gooseman have been implemented!
	- New names for most of the weapons.
	- The weapons act a mite differently.  You must reload now when you run out of ammo, and are able to reload the shotgun one shell at a time.  Also, the ammo counts for the weapons have been changed to reflect real life (!) guns.
	- The weapons eject shells now - The server may turn this off by typing "shelloff 1" into the console if this hinders net play.
	- The sniper rifle has a model now that is in view when not looking in the scope.  Also, it should be more accurate - about as accurate as v.91 and a half before we mucked it up.
* You are now limited to holding one grenade - which is a mite less powerful than before.  (it still packs a wopper though)
* The version logs will now contain many instances of the word "mite."

New in v.92
* The sniper rifle is now much, much more accurate!
* The two grenades bug (would fire two grenades when you die sometimes) is now fixed.
* Dropping the sniper rifle while using it no longer causes "problems"
* The jump kick has been tweaked.  You will no longer be "kicked back" by stationary targets.

New in v.91
* The "drop weapon" command will drop your unique weapon, even if you are using it.
* The "sniper" command allows you to toggle whether or not you are looking through the lens of the rifle (so you can put at your hip and walk around)
* The sniper rifle reloads more quickly.
* The server setting "actionmaps 1" or the cmd line "+set actionmaps 1" will rotate between the three action quake maps we have so far.
* The machinegun "rides up" like in singleplayer quake2.
* The handcannon is now less powerful.

New in v.90
* Shooting while walking makes you less accurate than while standing still, but more accurate than running.
* Shooting while crouching makes you more accurate than while standing still.
* The lasersight now makes you as accurate as you would be if you were crouching no matter what you are doing.
* Jumping into someone kicks them (a jumpkick)- it does 20 damage, knocks the target back pretty darn far, and disarms the person (forces him to drop his unique weapon)

New in v.89
* You cannot fire accurately while running.

New in v.88
* You can no longer drop grenades if you are using them.
* If someone shoots his enemy off a ledge, out a window etc. causing them to die from fall damage, the attacker recieves a frag and the target does not lose one.
* One or two new death messages.

New in v.87
* Servers no longer crash because of windows (we removed windows - if id tells you that you shouldn't have something in deathmatch, they mean it!)
* Gibbing should no longer occur, even with telefragging and the handcannon.

New in v.85

* Short falls do not cause fall damage (although long falls still cause the same amount of damage)
* The handcannon now shoots 35 pellets each 3 times as powerful as each of the 100(!) pellets it used to shoot.  The result: the handcannon still works the same, except it might be more random at long distances (which is good) We did this to fix the multiple overflow errors the handcannon had caused.
* Items (kevlar vest, silencer, lasersight) now spawn even if you decide to play more than one game!
* Lava now deals damage normally.
* The clips and magazines are now fullbright, and much easier to see.
* Bandaging is now independent of reloading (ie you shouldnt be healed when you reload the shotgun) 



 Other Credits
 -------------
 Well, too many people to thank them all, really, but I would like to thank Snigglet for our status bar icons,  
 Nirrad for a load of web graphics, Abraxis for the grenade model, DogFaceGremlin (Pietro's little brother) for the 
 Sabatoge skin, Cold Fusion and Cable for the slipper and box-o-shells models/skins, and shiro for our channel on 
 EFNet (#action) and for the Mr. T skin.    Also thanks to our beta testers, and to Dr Caliban for setting up a test 
 server.

 Those folks at QDevels were essential to the building of the mod, thanks.

 And of course the guys at id.

 Of course I'm forgetting people, especially people who contributed skins. :P  If I left you out 
 write me and give me crap about it, but -only- if you are the one who did the original work and 
 we included it in the client pak.

 
 Copyright and Distribution Permissions
 --------------------------------------
 
 This patch is freely distributable provided that this readme is
 distributed as well and is unchanged.
 
 All the new art, models, code, maps, and sounds are copyright The
 A-Team 1998.  Basically, if we made it, it's ours.
 
 DISCLAIMER:  We have tested this modification and found it to be
 totally safe.  However, we cannot be held responsible for
 anything that does happen to your computer resulting from the use of
 this mod.  If something does happen, please write us
 so that we can try to correct the problem.
 
 Contact
 -------
 You can find this mod and it's webpage at
 
 - http://action.telegragged.com
 
 We can be emailed at
 
 - ateam@telefragged.com
 
 We have an IRC room on EFNet at

 - #action
