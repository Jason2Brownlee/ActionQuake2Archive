================================================================
S.A.S (Special Air Service)
Plug-in Quake2 player model
by HitmanDaz                      e-mail: daz@cybermodels.co.uk
(Darren Pattenden)                        www.cybermodels.co.uk 
================================================================
DESCRIPTION:
Based on the British anti-terrorist force,the Special Air Service.
Full permission was given for inclusion in this Action Quake2 release.

INSTALLATION:
Unzip the files into a folder called SAS in your Quake2/baseq2/
players directory.
Copy all the sound files from the male player folder into your
SAS folder.


TOOLS USED:
3dstudio Max and character studio for modelling and animation.
Q2 modeller for compiling and NST and PaintShopPro for mapping and 
skinning.

COMMENTS:
Please consult me If you wish to use this model for anything other
than personal use.

CREDITS:
id software,Npherno for the awesome NST,Phillip Martin for the equally
essential Q2modeller and the boys at Planetquake.com/q2pmp.


I'll get round to doing some other skins when I'm finished on 
Dungeon Keeper 2!


Enjoy!

Daz
www.cybermodels.co.uk/html/dazhome.html